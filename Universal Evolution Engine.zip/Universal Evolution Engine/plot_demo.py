import csv
import sys
import os
import matplotlib
import matplotlib.pyplot as plt

matplotlib.rcParams['font.size'] = 11
matplotlib.rcParams['axes.linewidth'] = 1.0
matplotlib.rcParams['font.family'] = 'DejaVu Sans'

def load(path):
    d = {}
    with open(path, 'r') as f:
        reader = csv.DictReader(f)
        for k in reader.fieldnames:
            d[k] = []
        for row in reader:
            for k in reader.fieldnames:
                d[k].append(float(row[k]))
    return d

def fig1(d, out, pulse_tick=None):
    q0 = d['Q'][0]
    dev = [(q - q0) for q in d['Q']]

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(d['tick'], dev, color='black', linewidth=1.2,
            label='Q(t) \u2212 Q(0)')
    ax.axhline(y=0, color='red', linestyle='--',
               linewidth=0.8, label='exact conservation')
    if pulse_tick is not None:
        ax.axvline(x=pulse_tick, color='gray', linestyle=':',
                   linewidth=0.9, label='pulse at t=%d' % pulse_tick)
    ax.set_ylim(-2e-6, 2e-6)
    ax.set_xlabel('Time step (tick)')
    ax.set_ylabel('Absolute deviation of Q   (\u00d7 10$^{-6}$)')
    ax.set_title('Fig.1  Global conservation check')
    ax.legend(loc='upper right', fontsize=9)
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(out + '.pdf')
    plt.savefig(out + '.png', dpi=300)
    plt.close()

def fig2(d, out, pulse_tick=None):
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(d['tick'], d['E_total'], color='#1f77b4',
            linewidth=1.3, label='E_total (held)')
    ax.plot(d['tick'], d['E_diss'], color='#d62728',
            linewidth=1.3, label='E_diss (cumulative)')
    if pulse_tick is not None:
        ax.axvline(x=pulse_tick, color='gray', linestyle=':',
                   linewidth=0.9, label='pulse at t=%d' % pulse_tick)
    ax.set_xlabel('Time step (tick)')
    ax.set_ylabel('Energy')
    ax.set_title('Fig.2  Energy decay and recovery')
    ax.legend(loc='center right')
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(out + '.pdf')
    plt.savefig(out + '.png', dpi=300)
    plt.close()

def fig3(d, out):
    fig, ax1 = plt.subplots(figsize=(7, 4))
    ax1.plot(d['tick'], d['entropy_ratio'], color='#2ca02c',
             linewidth=1.3, label='Entropy ratio')
    ax1.set_xlabel('Time step (tick)')
    ax1.set_ylabel('Entropy ratio', color='#2ca02c')
    ax1.tick_params(axis='y', labelcolor='#2ca02c')
    ax1.set_ylim(0, 1.05)
    ax1.axhspan(0.4, 0.7, alpha=0.15, color='orange',
                label='self-organized region')
    ax1.grid(alpha=0.3)

    if 'active_nodes' in d:
        ax2 = ax1.twinx()
        ax2.plot(d['tick'], d['active_nodes'], color='#9467bd',
                 linewidth=1.0, label='active nodes')
        ax2.plot(d['tick'], d['active_couplings'], color='#8c564b',
                 linewidth=1.0, linestyle='--', label='couplings')
        ax2.set_ylabel('Topology size', color='#9467bd')
        ax2.tick_params(axis='y', labelcolor='#9467bd')
        ax2.legend(loc='upper right', fontsize=9)

    fig.suptitle('Fig.3  Entropy ratio and topology')
    fig.tight_layout()
    plt.savefig(out + '.pdf')
    plt.savefig(out + '.png', dpi=300)
    plt.close()

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python plot.py <data.csv> [pulse_tick]")
        sys.exit(1)

    path = sys.argv[1]
    if not os.path.exists(path):
        print("[error] file not found: %s" % path)
        sys.exit(1)

    pulse_tick = None
    if len(sys.argv) >= 3:
        try:
            pulse_tick = int(sys.argv[2])
        except ValueError:
            pass

    prefix = os.path.splitext(os.path.basename(path))[0]

    d = load(path)
    fig1(d, prefix + '_fig1_conservation', pulse_tick)
    fig2(d, prefix + '_fig2_energy', pulse_tick)
    fig3(d, prefix + '_fig3_entropy')

    print("[done] %s_fig1 / %s_fig2 / %s_fig3" % (prefix, prefix, prefix))